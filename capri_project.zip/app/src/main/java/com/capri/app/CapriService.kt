package com.capri.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class CapriService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var face: ImageView
    private lateinit var bubble: TextView
    private lateinit var prefs: SharedPreferences
    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var commandMode = false
    private var running = true
    private var tickRun: Runnable? = null
    private val hide = Runnable { bubble.visibility = View.GONE }

    // คำเรียก: เพิ่มได้ตามที่ระบบถอดเสียงออกมา (ตัวพิมพ์เล็ก)
    private val wake = listOf("คาพริ", "คาพี", "ตาปี", "กาปิ", "คาปี", "กาพริ", "แคปรี", "capri", "capi", "kapi")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("capri", MODE_PRIVATE)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startFg()
        buildOverlay()
        listen()
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        rec?.destroy()
        try { wm.removeView(root) } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("capri", "Capri", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "capri")
            .setContentTitle("Capri กำลังฟังอยู่")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun buildOverlay() {
        val d = resources.displayMetrics.density
        face = ImageView(this)
        face.setImageResource(R.drawable.capri_idle)
        face.layoutParams = LinearLayout.LayoutParams((110 * d).toInt(), (100 * d).toInt())

        bubble = TextView(this)
        bubble.setTextColor(0xFFFFFFFF.toInt())
        bubble.setBackgroundColor(0xCC000000.toInt())
        bubble.setPadding(16, 8, 16, 8)
        bubble.textSize = 14f
        bubble.maxWidth = (220 * d).toInt()
        bubble.visibility = View.GONE

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(face)
        root.addView(bubble)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 40
        lp.y = 300

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = sx + dx
                        lp.y = sy + dy
                        wm.updateViewLayout(root, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) startCommand()
                }
            }
            true
        }
        wm.addView(root, lp)
    }

    private fun startCommand() {
        commandMode = true
        say("ว่าไง")
        h.removeCallbacksAndMessages(RESTART)
        listen()
    }

    private fun listen() {
        if (!running) return
        rec?.destroy()
        rec = null
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("เครื่องนี้ไม่มีระบบรู้จำเสียง")
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(res: Bundle?) {
                val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                handle(t)
            }
            override fun onError(e: Int) {
                commandMode = false
                restart(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        rec = r
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        r.startListening(i)
    }

    private fun restart(ms: Long) {
        h.postAtTime({ listen() }, RESTART, SystemClock.uptimeMillis() + ms)
    }

    private fun handle(text: String) {
        val t = text.trim()
        if (commandMode) {
            commandMode = false
            if (t.isNotEmpty()) run(t)
            restart(600L)
            return
        }
        val low = t.lowercase()
        var hit = -1
        var len = 0
        for (w in wake) {
            val i = low.indexOf(w)
            if (i >= 0 && (hit < 0 || i < hit)) { hit = i; len = w.length }
        }
        if (hit < 0) {
            if (t.isNotEmpty()) peek("ได้ยิน: $t")
            restart(300L)
            return
        }
        val rest = t.substring(hit + len).trim()
        if (rest.isEmpty()) {
            commandMode = true
            say("ว่าไง")
            restart(250L)
        } else {
            run(rest)
            restart(600L)
        }
    }

    private fun run(c: String) {
        val name = prefs.getString("name", "") ?: ""
        val low = c.lowercase()

        val nm = Regex("(?:(?:ผม|ฉัน|หนู|เรา)ชื่อ|เรียก(?:ผม|ฉัน|หนู|เรา)?ว่า)\\s*(\\S+)").find(c)
        if (nm != null) {
            val n = nm.groupValues[1]
            prefs.edit().putString("name", n).apply()
            say("ยินดีที่ได้รู้จักนะ $n")
            return
        }
        val kSong = "เปิดเพลง"
        val song = c.indexOf(kSong)
        if (song >= 0) {
            val q = c.substring(song + kSong.length).trim()
            say(if (q.isEmpty()) "เปิด YouTube ให้นะ" else "เปิดเพลง $q ให้นะ")
            openUrl(if (q.isEmpty()) "https://www.youtube.com" else "https://www.youtube.com/results?search_query=" + Uri.encode(q))
            return
        }
        if (low.contains("youtube") || c.contains("ยูทูป") || c.contains("ยูทูบ")) {
            say("เปิด YouTube ให้นะ")
            openUrl("https://www.youtube.com")
            return
        }
        val kSearch = "ค้นหา"
        val s = c.indexOf(kSearch)
        if (s >= 0) {
            val q = c.substring(s + kSearch.length).trim()
            say(if (q.isEmpty()) "เปิด Google ให้นะ" else "ค้นหา $q ให้นะ")
            openUrl(if (q.isEmpty()) "https://www.google.com" else "https://www.google.com/search?q=" + Uri.encode(q))
            return
        }
        if (low.contains("google") || c.contains("กูเกิล")) {
            say("เปิด Google ให้นะ")
            openUrl("https://www.google.com")
            return
        }
        if (c.contains("ชื่ออะไร")) {
            say(if (name.isEmpty()) "ยังไม่รู้ชื่อเลย บอกได้นะ เช่น ผมชื่อ ..." else "คุณชื่อ $name")
            return
        }
        if (c.contains("สวัสดี")) {
            say(if (name.isEmpty()) "สวัสดี! คุณชื่ออะไรเหรอ" else "สวัสดี $name")
            return
        }
        say("ยังไม่เข้าใจคำสั่งนี้ เฟสหน้าจะคุยได้เก่งขึ้น")
    }

    private fun openUrl(url: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            say("เปิดไม่ได้")
        }
    }

    private fun peek(t: String) {
        bubble.text = t
        bubble.visibility = View.VISIBLE
        h.removeCallbacks(hide)
        h.postDelayed(hide, 2000L)
    }

    private fun say(t: String) {
        bubble.text = t
        bubble.visibility = View.VISIBLE
        val ms = minOf(5000L, t.length * 70L + 500L)
        val end = SystemClock.uptimeMillis() + ms
        tickRun?.let { h.removeCallbacks(it) }
        var n = 0
        val tick = object : Runnable {
            override fun run() {
                if (SystemClock.uptimeMillis() < end) {
                    face.setImageResource(if (n++ % 2 == 0) R.drawable.capri_talk else R.drawable.capri_idle)
                    h.postDelayed(this, 160L)
                } else {
                    face.setImageResource(R.drawable.capri_idle)
                }
            }
        }
        tickRun = tick
        h.post(tick)
        h.removeCallbacks(hide)
        h.postDelayed(hide, ms + 2500L)
    }

    companion object {
        private val RESTART = Any()
    }
}
