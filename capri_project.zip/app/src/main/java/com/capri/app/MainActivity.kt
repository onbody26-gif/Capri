package com.capri.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var asked = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(p, p * 2, p, p)

        val info = TextView(this)
        info.text = "Capri\n\nกด เริ่ม แล้วอนุญาตไมค์ การแจ้งเตือน และ แสดงทับแอปอื่น\n\nเรียก: คาพริ / คาพี / ตาปี / กาปิ หรือแตะที่ตาแล้วพูดคำสั่ง\nตัวอย่าง: คาพี เปิดเพลง ... / ผมชื่อ ... / ค้นหา ... / เปิด Google"
        info.textSize = 16f

        val start = Button(this)
        start.text = "เริ่ม Capri"
        start.setOnClickListener { go() }

        val stop = Button(this)
        stop.text = "หยุด Capri"
        stop.setOnClickListener { stopService(Intent(this, CapriService::class.java)) }

        col.addView(info)
        col.addView(start)
        col.addView(stop)
        setContentView(col)
    }

    private fun go() {
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty() && !asked) {
            asked = true
            requestPermissions(missing.toTypedArray(), 1)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "ต้องอนุญาตไมค์ก่อน", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "เปิดสวิตช์ แสดงทับแอปอื่น ให้ Capri แล้วกลับมากด เริ่ม อีกครั้ง", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, CapriService::class.java))
        finish()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        go()
    }
}
